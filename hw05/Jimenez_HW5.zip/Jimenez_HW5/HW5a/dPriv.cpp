#include "dPriv.h"

dPriv::dPriv( ) { }
dPriv::~dPriv( ){ }
void dPriv::print( ) { 
   cout << "dPriv" << endl;
   //std::cout << "privB: " << privB; 
   //std::cout << ", protB: " << protB;
   //std::cout << ", publicB: " << publicB; 
   cout << endl << endl;
}

