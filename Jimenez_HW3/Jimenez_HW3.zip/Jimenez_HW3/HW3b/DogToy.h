#ifndef DOGTOY_H_
#define DOGTOY_H_
#include "Duck.h"
#include "Squeak.h"
#include "NoFly.h"

class DogToy : public Duck {
public:

   DogToy( );
   virtual ~DogToy( );
};
#endif /* DOGTOY_H_ */
