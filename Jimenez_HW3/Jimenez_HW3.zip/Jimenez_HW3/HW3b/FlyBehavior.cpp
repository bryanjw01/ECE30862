#include <iostream>
#include <string>
#include "FlyBehavior.h"

FlyBehavior::FlyBehavior( ) { }

FlyBehavior::~FlyBehavior( ){ }

void FlyBehavior::fly( ) { }

