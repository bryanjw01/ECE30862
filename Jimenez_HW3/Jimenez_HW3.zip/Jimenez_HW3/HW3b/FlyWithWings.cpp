#include <iostream>
#include "FlyWithWings.h"

// PUT CODE HERE.  Use NoFly.h as an example
FlyWithWings::FlyWithWings( ) { }
FlyWithWings::~FlyWithWings( ) { }
void FlyWithWings::fly( ) {
    std::cout << "I'm flying!" << std::endl;
}
