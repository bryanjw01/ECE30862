#include <iostream>
#include <string>
#include "Squeak.h"

// PUT CODE HERE.  Use QuackQuack.cpp as an example
Squeak::Squeak( ) { }

Squeak::~Squeak( ){ }

void Squeak::quack( ) {
    std::cout << "squeak" << std::endl;
}
