#ifndef FLYWITHWINGS_H_
#define FLYWITHWINGS_H_
#include "FlyBehavior.h"

class FlyWithWings : public FlyBehavior {
public:

    FlyWithWings( );
    virtual ~FlyWithWings( );
    virtual void fly( );

};
#endif /* FLYWITHWINGS_H_ */
