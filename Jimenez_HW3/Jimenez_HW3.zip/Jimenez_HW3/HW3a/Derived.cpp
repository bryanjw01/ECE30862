#include "Derived.h"
#include<iostream>
Derived::Derived( ) { }
Derived::~Derived( ) { }

void Derived::f2(){
    std::cout<<"Derived f2"<<std::endl;
}
// add necessary functions here
