#ifndef BASE_H_
#define BASE_H_

class Base {
public:
   Base( );
   virtual ~Base( );
    void f1();
    virtual void f2();
   // add necessary functions here

};
#endif /*BASE_H*/
